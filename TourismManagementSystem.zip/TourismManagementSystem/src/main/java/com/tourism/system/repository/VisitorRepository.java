package com.tourism.system.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tourism.system.entity.Visitor;
@Repository
public interface VisitorRepository extends JpaRepository<Visitor, Long>{

	 Visitor findByVisitorName(String visitorName);

	 Visitor findByVisitorMobileNumber(String visitorMobileNumber);

	 Visitor findByVisitorEmailId(String visitorEmailId);

	 Visitor findByVisitorAddress(String visitorAddress);

	

}
