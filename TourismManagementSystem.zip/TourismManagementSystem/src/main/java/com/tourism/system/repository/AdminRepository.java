package com.tourism.system.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tourism.system.entity.Admin;
@Repository
public interface AdminRepository extends JpaRepository<Admin, Long> {

    	Admin findByAdminName(String adminName);

    	Admin findByAdminPassword(String adminPassword);

    	Admin findByAdminEmailId(String adminEmailId);

        Admin findByAdminPackage(Float adminPackage);

    	Admin findByAdminRoomType(String adminRoomType);

		Admin findByAdminAccommodationType(String adminAccommodationType);
	

}
