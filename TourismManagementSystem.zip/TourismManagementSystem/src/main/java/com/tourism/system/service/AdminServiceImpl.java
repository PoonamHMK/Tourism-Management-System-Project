package com.tourism.system.service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tourism.system.entity.Admin;
import com.tourism.system.error.AdminNotFoundException;
import com.tourism.system.repository.AdminRepository;

@Service
public class AdminServiceImpl implements AdminService {
	 @Autowired
	 AdminRepository adminRepo;
	 
//insert
	@Override
	public Admin saveAdmin(Admin admin) {
		// TODO Auto-generated method stub
		return adminRepo.save(admin);
	}

	//find all
	@Override
	public List<Admin> fetchAdminList() {
		// TODO Auto-generated method stub
		return adminRepo.findAll();
	}
// display all records
	@Override
	public Admin fetchAdminById(Long adminId) throws AdminNotFoundException {
		
			Optional<Admin> admin1= adminRepo.findById(adminId);//check in database
			if(!admin1.isPresent()) {
				throw new AdminNotFoundException("Admin not available");
			}
			return adminRepo.findById(adminId).get() ;		
	}
//delete the record
	@Override
	public void deleteAdminById(Long adminId) throws AdminNotFoundException {
		Optional<Admin> admin1= adminRepo.findById(adminId);//check in database
        if(!admin1.isPresent()) 
        {
      	  throw new AdminNotFoundException("Admin not available");
        }
        else 
        {
		 adminRepo.deleteById(adminId);		
	}
	}
	
//update record
	@Override
	public Admin updateAdmin(Long adminId, Admin admin) throws AdminNotFoundException {
		Optional<Admin> admin1= adminRepo.findById(adminId);//check id
		Admin admDB=null;
		if(admin1.isPresent()) 
		{
			//id
			admDB=	adminRepo.findById(adminId).get();
			//Name
			if(Objects.nonNull(admin.getAdminName()) && !"".equalsIgnoreCase(admin.getAdminName())) {
			admDB.setAdminName(admin.getAdminName());
			}
			//Password
			if(Objects.nonNull(admin.getAdminPassword()) && !"".equalsIgnoreCase(admin.getAdminPassword())) {
				admDB.setAdminPassword(admin.getAdminPassword());
				System.out.println(admin.getAdminPassword());
			}
			//EmailId
			if(Objects.nonNull(admin.getAdminEmailId()) && !"".equalsIgnoreCase(admin.getAdminEmailId())) {
				admDB.setAdminEmailId(admin.getAdminEmailId());
				System.out.println(admin.getAdminEmailId());
			}
			//AccomodationType
			if(Objects.nonNull(admin.getAdminAccommodationType()) && !"".equalsIgnoreCase(admin.getAdminAccommodationType())) {
				admDB.setAdminAccommodationType(admin.getAdminAccommodationType());
				System.out.println(admin.getAdminAccommodationType());
			}
			//Package
			if(Objects.nonNull(admin.getAdminPackage()) && !"".equals(admin.getAdminPackage())) {
				admDB.setAdminPackage(admin.getAdminPackage());
				System.out.println(admin.getAdminPackage());
			}
			//RoomType
			if(Objects.nonNull(admin.getAdminRoomType()) && !"".equalsIgnoreCase(admin.getAdminRoomType())) {
				admDB.setAdminRoomType(admin.getAdminRoomType());
				System.out.println(admin.getAdminRoomType());
			}
		return adminRepo.save(admDB);
	 }//if
	 else 
	    {
		throw new AdminNotFoundException("Admin Not available");
	
       }
	}
//get the name
	
	@Override
	public Admin fetchAdminByName(String adminName) 
	{
		// TODO Auto-generated method stub
		return adminRepo.findByAdminName(adminName);
	}
	
//password
	@Override
	public Admin fetchAdminByPassword(String adminPassword) 
	{
		// TODO Auto-generated method stub
		return adminRepo.findByAdminPassword(adminPassword);
	}
 //Email
	@Override
	public Admin fetchAdminByEmailId(String adminEmailId)
	{
		// TODO Auto-generated method stub
		return adminRepo.findByAdminEmailId(adminEmailId) ;
	}
//AccommodationType
	@Override
	public Admin fetchAdminByAccommodationType(String adminAccommodationType) 
	{
		// TODO Auto-generated method stub
		return  adminRepo.findByAdminAccommodationType(adminAccommodationType);
		
	}
//package
	@Override
	public Admin fetchAdminByPackage(Float adminPackage)
	{
		// TODO Auto-generated method stub
		return adminRepo.findByAdminPackage(adminPackage);
	}
//Room type
	@Override
	public Admin fetchAdminByRoomType(String adminRoomType)
	{
		// TODO Auto-generated method stub
		return adminRepo.findByAdminRoomType(adminRoomType) ;
	}
}

	

