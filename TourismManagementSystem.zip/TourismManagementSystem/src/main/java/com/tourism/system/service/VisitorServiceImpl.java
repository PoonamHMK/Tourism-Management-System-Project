package com.tourism.system.service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tourism.system.entity.Visitor;
import com.tourism.system.error.VisitorNotFoundException;
import com.tourism.system.repository.VisitorRepository;

@Service
public class VisitorServiceImpl implements VisitorService{
	@Autowired
	VisitorRepository visitorRepo;
	
//insert records
	@Override
	public Visitor saveVisitor(Visitor visitor)
	{
		// TODO Auto-generated method stub
		return visitorRepo.save(visitor);
	}
//display all records
	@Override
	public List<Visitor> fetchVisitorList()
	{
		// TODO Auto-generated method stub
		return visitorRepo.findAll();
	}
//displaya record by id
	@Override
	public Visitor fetchVisitorById(Long visitorId) throws VisitorNotFoundException 
		{
			Optional<Visitor> visitor1= visitorRepo.findById(visitorId);//check in database
			if(!visitor1.isPresent()) {
				throw new VisitorNotFoundException("Visitor not available");
			}
			return visitorRepo.findById(visitorId).get() ;
	      }
	 
//delete record by id
	@Override
	public void deleteVisitorById(Long visitorId) throws VisitorNotFoundException {
		Optional<Visitor> visitor1= visitorRepo.findById(visitorId);//check in database
        if(!visitor1.isPresent()) {
      	  throw new VisitorNotFoundException("Visitor not available");
        }
        else {
		 visitorRepo.deleteById(visitorId);
        }		
	}
// update record
	@Override
	public Visitor updateVisitor(Long visitorId, Visitor visitor) throws VisitorNotFoundException 
	{
		Optional<Visitor> visitor1= visitorRepo.findById(visitorId);//check id
		Visitor visDB=null;
		if(visitor1.isPresent()) 
		{
			// id
			visDB=	visitorRepo.findById(visitorId).get();
            //Name
			if(Objects.nonNull(visitor.getVisitorName()) && !"".equalsIgnoreCase(visitor.getVisitorName())) {
			visDB.setVisitorName(visitor.getVisitorName());
			}
			// MobileNumber
			if(Objects.nonNull(visitor.getVisitorMobileNumber()) && !"".equalsIgnoreCase(visitor.getVisitorMobileNumber())) {
				visDB.setVisitorMobileNumber(visitor.getVisitorMobileNumber());
				System.out.println(visitor.getVisitorMobileNumber());
			}
			//MailId
			if(Objects.nonNull(visitor.getVisitorEmailId()) && !"".equalsIgnoreCase(visitor.getVisitorEmailId())) {
				visDB.setVisitorEmailId(visitor.getVisitorEmailId());
				System.out.println(visitor.getVisitorEmailId());
			}
			//Address
			if(Objects.nonNull(visitor.getVisitorAddress()) && !"".equalsIgnoreCase(visitor.getVisitorAddress())) {
				visDB.setVisitorAddress(visitor.getVisitorAddress());
				System.out.println(visitor.getVisitorAddress());
			}
			return visitorRepo.save(visDB) ;
	}//if
	else 
	{
		throw new VisitorNotFoundException("Visitor Not available");
	}
	}
//get record by name
	@Override
	public Visitor fetchVisitorByName(String visitorName) 
	{
		// TODO Auto-generated method stub
		return visitorRepo.findByVisitorName(visitorName);
	}
//get record by mbl num
	@Override
	public Visitor fetchVisitorByMobileNumber(String visitorMobileNumber)
	{
		// TODO Auto-generated method stub
		return visitorRepo.findByVisitorMobileNumber(visitorMobileNumber);
	}
	
//get record by Email id
	@Override
	public Visitor fetchVisitorByEmailId(String visitorEmailId)
	{
		// TODO Auto-generated method stub
		return visitorRepo.findByVisitorEmailId(visitorEmailId);
	}

//get record by address
	@Override
	public Visitor fetchVisitorByAddress(String visitorAddress)
	{
		// TODO Auto-generated method stub
		return visitorRepo.findByVisitorAddress(visitorAddress);
	}

}


	

	
	

